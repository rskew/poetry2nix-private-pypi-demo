from setuptools import setup

setup(
    name='test_package',
    packages=['test_package'],
    description='Package to serve from the test pypi server',
    version='0.1',
)
