def hihi():
    print("HI")
